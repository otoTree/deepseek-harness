/** Author-facing SDK facade backed by an installation-scoped capability transport. */
import type { PluginCapabilityTransport, PluginSdk, PluginErrorCode } from '@deepseek-ai/dsh-plugin-protocol';
export type * from '@deepseek-ai/dsh-plugin-protocol';
/** Stable error returned by an installation-scoped capability call. */
export declare class PluginSdkError extends Error {
    /** Stable platform error code. */
    readonly code: PluginErrorCode;
    /** HTTP status returned by the capability endpoint. */
    readonly status: number;
    constructor(code: PluginErrorCode, message: string, status: number);
}
/** Create the standard HTTP transport used by Host bridges and browser-side test clients.
 * @param options Activation URL, credential, and optional fetch implementation.
 * @returns A capability transport that maps failed responses to `PluginSdkError`.
 */
export declare function createHttpPluginTransport(options: {
    readonly baseUrl: string;
    readonly activationId: string;
    readonly token: string;
    readonly fetch?: typeof globalThis.fetch;
}): PluginCapabilityTransport;
/** Create one installation-scoped SDK. The transport owns authentication and revocation checks.
 * @param transport Installation-scoped capability transport.
 * @returns Author-facing identity, model, object, database, and cache facades.
 */
export declare function createPluginSdk(transport: PluginCapabilityTransport): PluginSdk;
//# sourceMappingURL=index.d.ts.map
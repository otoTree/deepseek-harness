/** Runtime helpers that bind an SDK transport to one Cordis activation lifetime. */
import type { Context, Plugin } from '@deepseek-ai/cordis';
import type { ClientWindowDefinition, ClientWindowInstance, PluginCapabilityTransport, PluginSdk } from '@deepseek-ai/dsh-plugin-protocol';
export { CordisPluginManager, type InstalledCordisEntry, type ManagedCordisProduct } from './manager.ts';
/** Create an SDK and a disposer that invalidates its transport after unload.
 * @param transport Platform transport bound to one activation lease.
 * @param onDispose Optional callback run once when the activation is disposed.
 * @returns The SDK facade and its idempotent disposer.
 */
export declare function bindPluginSdk(transport: PluginCapabilityTransport, onDispose?: () => void): {
    sdk: PluginSdk;
    dispose: () => void;
};
/** ESM exports accepted from a verified Host or Client target entry. */
export interface PluginTargetModule {
    /** Default Cordis plugin export. */
    readonly default?: Plugin;
    /** Named Cordis object-plugin entrypoint. */
    readonly apply?: (ctx: Context, config?: unknown) => unknown;
    /** Optional Cordis plugin display name. */
    readonly name?: string;
    /** Services required by a named object-plugin entrypoint. */
    readonly inject?: Plugin['inject'];
    /** Optional Cordis configuration schema. */
    readonly Config?: Plugin['Config'];
}
/** Optional activation controls for one target mount. */
export interface MountPluginTargetOptions {
    /** Installation configuration passed to the Cordis plugin. */
    readonly config?: unknown;
    /** Cancellation that disposes a target still waiting for required services. */
    readonly signal?: AbortSignal;
    /** Optional restricted window service scoped to this Client target. */
    readonly clientWindow?: ClientWindowService;
    /** Optional unique isolate name when several Client targets share a root. */
    readonly scopeName?: string;
}
/** Mount one verified target with an isolated installation-scoped SDK service.
 * @param ctx Parent Host or Client Cordis context.
 * @param module Verified target module exports.
 * @param sdk SDK bound to the target's current activation lease.
 * @param options Installation configuration and activation cancellation.
 * @returns An idempotent disposer that waits for target effects to stop.
 */
export declare function mountPluginTarget(ctx: Context, module: PluginTargetModule, sdk: PluginSdk, options?: MountPluginTargetOptions): Promise<() => Promise<void>>;
/** Install the SDK on a Cordis context for a plugin's declared activation scope.
 * @param ctx Cordis context that owns the plugin contribution.
 * @param transport Platform transport bound to the current activation.
 * @returns A disposer that removes the SDK and invalidates retained handles.
 */
export declare function installPluginSdk(ctx: Context, transport: PluginCapabilityTransport): () => void;
/** Platform operations used by the Host registry to materialize native windows. */
export interface ClientWindowPlatform {
    create(instance: ClientWindowInstance, definition: ClientWindowDefinition, input: unknown): Promise<void> | void;
    close(instance: ClientWindowInstance): Promise<void> | void;
    focus(instance: ClientWindowInstance): Promise<void> | void;
}
/** Build a platform adapter over an authenticated loopback window broker.
 * @param broker - Loopback endpoint and bearer token owned by the Host.
 * @returns Window operations that communicate with the broker.
 */
export declare function createClientWindowBrokerPlatform(broker: {
    url: string;
    token: string;
}): ClientWindowPlatform;
/** Read-only event emitted after a window instance changes state. */
export interface ClientWindowEvent {
    readonly kind: 'opened' | 'closed' | 'focused' | 'error';
    readonly instance: ClientWindowInstance;
    readonly error?: unknown;
}
/** Host-side registry for declarative Client window contributions. */
export declare class ClientWindowRegistry {
    private readonly platform;
    private readonly definitions;
    private readonly instances;
    private readonly listeners;
    private nextInstance;
    private readonly drainingPlugins;
    constructor(platform: ClientWindowPlatform);
    /** Register one normalized contribution and return its idempotent disposer.
     * @param definition - Validated contribution owned by one plugin.
     * @returns A disposer that unregisters the contribution and closes its windows.
     */
    register(definition: ClientWindowDefinition): () => void;
    /** Subscribe to opened, closed, focused, and window-local error events.
     * @param listener - Receives each window lifecycle event.
     * @returns A disposer that removes the listener.
     */
    subscribe(listener: (event: ClientWindowEvent) => void): () => void;
    /** Return the currently registered definitions.
     * @param pluginId - Optional owner filter.
     * @returns Definitions matching the owner filter.
     */
    listDefinitions(pluginId?: string): readonly ClientWindowDefinition[];
    /** Return live instances, optionally filtered by plugin.
     * @param pluginId - Optional owner filter.
     * @returns Current window instances matching the owner filter.
     */
    list(pluginId?: string): readonly ClientWindowInstance[];
    /** Open a declared contribution; singleton contributions focus the existing instance.
     * @param pluginId - Contribution owner.
     * @param contributionId - Declared window contribution.
     * @param input - Input passed to the platform window.
     * @param ownerWindowId - Optional Client window that owns the new instance.
     * @returns The created or focused instance.
     */
    open(pluginId: string, contributionId: string, input: unknown, ownerWindowId?: string): Promise<ClientWindowInstance>;
    /** Close one live window instance without affecting sibling windows.
     * @param windowInstanceId - Instance to close; an unknown id is ignored.
     * @returns Completion after the platform close settles.
     */
    close(windowInstanceId: string): Promise<void>;
    /** Focus one live window instance.
     * @param windowInstanceId - Instance to focus.
     * @returns Completion after the platform focus settles.
     */
    focus(windowInstanceId: string): Promise<void>;
    /** Close every window owned by one plugin during disable or upgrade.
     * @param pluginId - Owner whose open windows must close.
     * @returns Completion after all close operations settle.
     */
    closePlugin(pluginId: string): Promise<void>;
    /** Reject new opens while an upgrade or disable drains existing instances.
     * @param pluginId - Owner to place in draining state.
     */
    beginDrain(pluginId: string): void;
    /** Resume opens after a failed or cancelled reconciliation.
     * @param pluginId - Owner to resume when its definitions remain registered.
     */
    endDrain(pluginId: string): void;
    private key;
    private emit;
}
/** Client-side restricted window service; callers never receive native handles. */
export interface ClientWindowService {
    /** Open a declared window contribution through the Host.
     * @param contributionId - Registered contribution id.
     * @param input - Optional view input.
     * @returns The new or existing window instance.
     */
    open(contributionId: string, input?: unknown): Promise<ClientWindowInstance>;
    /** Close one Host-owned window instance.
     * @param windowInstanceId - Instance to close.
     * @returns Completion after the Host closes the window.
     */
    close(windowInstanceId: string): Promise<void>;
    /** Focus one Host-owned window instance.
     * @param windowInstanceId - Instance to focus.
     * @returns Completion after the Host focuses the window.
     */
    focus(windowInstanceId: string): Promise<void>;
    /** List instances available to this plugin activation.
     * @returns The active window instances.
     */
    list(): Promise<readonly ClientWindowInstance[]>;
}
/** Build a Client window service over the existing capability transport.
 * @param transport - Activation-scoped Host capability transport.
 * @returns Restricted window operations for one Client target.
 */
export declare function createClientWindowService(transport: PluginCapabilityTransport): ClientWindowService;
/** Install the restricted Client window service for one Client Context.
 * @param ctx - Cordis Context receiving the Client service.
 * @param service - Host-backed window service for the active target.
 * @returns A disposer that removes the service from the Context.
 */
export declare function installClientWindow(ctx: Context, service: ClientWindowService): () => void;
declare module '@deepseek-ai/cordis' {
    interface Context {
        pluginSdk: PluginSdk;
    }
    interface Context {
        clientWindow: ClientWindowService;
    }
    interface Context {
        clientWindows: ClientWindowRegistry;
    }
}
//# sourceMappingURL=index.d.ts.map
/** Product-owned Cordis Loader groups for verified, installed Host packages. */
import type { Context, Fiber } from '@deepseek-ai/cordis';
import type { PluginSdk } from '@deepseek-ai/dsh-plugin-protocol';
/** Installed entry supplied by the package verifier and store. */
export interface InstalledCordisEntry {
    readonly url: string;
    readonly config?: unknown;
}
/** One product's live Loader group and contribution owners. */
export interface ManagedCordisProduct {
    readonly groupId: string;
    readonly owners: ReadonlySet<Fiber>;
    /** Remove the product group and wait for its Cordis effects to stop.
     * @returns Completion of Loader removal; a failed removal can be retried.
     */
    dispose(): Promise<void>;
}
/** Connects market installations to the running profile's Cordis Loader. */
export declare class CordisPluginManager {
    private readonly ctx;
    private readonly products;
    constructor(ctx: Context);
    /** Install a verified product composition under an SDK-isolated Loader group.
     * @param installationId - Organization-scoped market installation identity.
     * @param entries - Verified Host entry URLs and their installation configuration.
     * @param providerUrl - Host-owned module providing the activation SDK.
     * @param sdk - SDK bound to the current activation lease.
     * @param signal - Cancels preparation and removes the incomplete Loader group.
     * @returns The live group and all package fibers owning its registrations.
     */
    load(installationId: string, entries: readonly InstalledCordisEntry[], providerUrl: string, sdk: PluginSdk, signal: AbortSignal): Promise<ManagedCordisProduct>;
    /** Remove a live or partially loaded composition; failed disposal remains retryable.
     * @param installationId - Organization-scoped market installation identity.
     * @returns Completion after the owned Loader group has left the profile.
     */
    remove(installationId: string): Promise<void>;
}
//# sourceMappingURL=manager.d.ts.map
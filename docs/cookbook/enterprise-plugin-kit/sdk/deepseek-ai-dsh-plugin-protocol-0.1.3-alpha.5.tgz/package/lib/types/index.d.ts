/** Shared enterprise plugin manifest, lifecycle, and SDK contracts. */
import { z } from 'zod';
export * from './types.ts';
declare const pluginTarget: z.ZodDiscriminatedUnion<[z.ZodObject<{
    compatibility: z.ZodString;
    kind: z.ZodLiteral<"client">;
    entry: z.ZodString;
    moduleId: z.ZodString;
    contributions: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"slot">;
        id: z.ZodString;
        slot: z.ZodString;
        multiplicity: z.ZodEnum<{
            one: "one";
            many: "many";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"window">;
        id: z.ZodString;
        surface: z.ZodString;
        multiplicity: z.ZodEnum<{
            many: "many";
            singleton: "singleton";
        }>;
        titleKey: z.ZodString;
        shell: z.ZodEnum<{
            standard: "standard";
            minimal: "minimal";
        }>;
        defaultBounds: z.ZodOptional<z.ZodObject<{
            width: z.ZodNumber;
            height: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>], "kind">>>;
}, z.core.$strict>, z.ZodObject<{
    compatibility: z.ZodString;
    kind: z.ZodLiteral<"host">;
    entry: z.ZodString;
    contributions: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>], "kind">;
/** Runtime parser for package manifests accepted by the plugin SDK. */
export declare const pluginManifest: z.ZodObject<{
    schemaVersion: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
    pluginId: z.ZodString;
    name: z.ZodString;
    icon: z.ZodOptional<z.ZodString>;
    version: z.ZodString;
    targets: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        compatibility: z.ZodString;
        kind: z.ZodLiteral<"client">;
        entry: z.ZodString;
        moduleId: z.ZodString;
        contributions: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"slot">;
            id: z.ZodString;
            slot: z.ZodString;
            multiplicity: z.ZodEnum<{
                one: "one";
                many: "many";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"window">;
            id: z.ZodString;
            surface: z.ZodString;
            multiplicity: z.ZodEnum<{
                many: "many";
                singleton: "singleton";
            }>;
            titleKey: z.ZodString;
            shell: z.ZodEnum<{
                standard: "standard";
                minimal: "minimal";
            }>;
            defaultBounds: z.ZodOptional<z.ZodObject<{
                width: z.ZodNumber;
                height: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>], "kind">>>;
    }, z.core.$strict>, z.ZodObject<{
        compatibility: z.ZodString;
        kind: z.ZodLiteral<"host">;
        entry: z.ZodString;
        contributions: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>], "kind">>>;
    packages: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        version: z.ZodString;
        dependencies: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        targets: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            compatibility: z.ZodString;
            kind: z.ZodLiteral<"client">;
            entry: z.ZodString;
            moduleId: z.ZodString;
            contributions: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"slot">;
                id: z.ZodString;
                slot: z.ZodString;
                multiplicity: z.ZodEnum<{
                    one: "one";
                    many: "many";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"window">;
                id: z.ZodString;
                surface: z.ZodString;
                multiplicity: z.ZodEnum<{
                    many: "many";
                    singleton: "singleton";
                }>;
                titleKey: z.ZodString;
                shell: z.ZodEnum<{
                    standard: "standard";
                    minimal: "minimal";
                }>;
                defaultBounds: z.ZodOptional<z.ZodObject<{
                    width: z.ZodNumber;
                    height: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>], "kind">>>;
        }, z.core.$strict>, z.ZodObject<{
            compatibility: z.ZodString;
            kind: z.ZodLiteral<"host">;
            entry: z.ZodString;
            contributions: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>], "kind">>;
        presets: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            entry: z.ZodString;
        }, z.core.$strict>>>;
    }, z.core.$strict>>>;
    permissions: z.ZodDefault<z.ZodArray<z.ZodEnum<{
        "identity.read": "identity.read";
        "models.text": "models.text";
        "models.media": "models.media";
        "objects.read": "objects.read";
        "objects.write": "objects.write";
        "database.query": "database.query";
        "database.transaction": "database.transaction";
        "cache.read": "cache.read";
        "cache.write": "cache.write";
        "network.http": "network.http";
        "credentials.read": "credentials.read";
        "credentials.write": "credentials.write";
        "authorization.oauth": "authorization.oauth";
        "authorization.api-key": "authorization.api-key";
        "mcp.connect": "mcp.connect";
        "skills.register": "skills.register";
        "config.read": "config.read";
        "config.write": "config.write";
    }>>>;
    network: z.ZodOptional<z.ZodObject<{
        allowedHosts: z.ZodArray<z.ZodString>;
        maxResponseBytes: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    credentialDescriptors: z.ZodOptional<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        label: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            secret: "secret";
            oauth: "oauth";
            "api-key": "api-key";
        }>;
    }, z.core.$strict>>>;
    resources: z.ZodDefault<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            objects: "objects";
            database: "database";
            cache: "cache";
        }>;
        quotaBytes: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>>;
    sdk: z.ZodOptional<z.ZodObject<{
        minVersion: z.ZodString;
        maxVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    migrations: z.ZodDefault<z.ZodArray<z.ZodObject<{
        version: z.ZodNumber;
        statements: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>>;
    contributions: z.ZodDefault<z.ZodUnion<readonly [z.ZodArray<z.ZodString>, z.ZodRecord<z.ZodString, z.ZodJSONSchema>]>>;
    dependencies: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    build: z.ZodObject<{
        runtime: z.ZodString;
        lockfileDigest: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
/** One target together with its owning Cordis package, if the archive uses schema version 3. */
export interface ResolvedPluginTarget {
    readonly packageId: string | undefined;
    readonly packageName: string | undefined;
    readonly dependencies: Readonly<Record<string, string>>;
    readonly presets: readonly {
        readonly id: string;
        readonly entry: string;
    }[];
    readonly target: z.infer<typeof pluginTarget>;
}
/** Flatten legacy targets and schema-version-3 package targets for runtime consumers.
 * @param manifest - Parsed product release manifest.
 * @returns Targets with their owning package metadata.
 */
export declare function resolvePluginTargets(manifest: z.infer<typeof pluginManifest>): readonly ResolvedPluginTarget[];
//# sourceMappingURL=index.d.ts.map